package com.systemteam.util;

/**
 * Created by gaolei on 17/2/24.
 */

public class Constant {
    public static final String  gaodeKey="4eeb3dc8226242574fa33daa767126b2";

}
