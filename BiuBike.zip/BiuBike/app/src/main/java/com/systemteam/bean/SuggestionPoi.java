package com.systemteam.bean;

/**
 * Created by gaolei on 17/3/26.
 */

public class SuggestionPoi {
    public String position,district;
}
