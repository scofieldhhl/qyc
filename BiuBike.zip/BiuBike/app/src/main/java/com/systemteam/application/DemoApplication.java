package com.systemteam.application;

import android.app.Application;
import android.os.Environment;

import com.baidu.mapapi.SDKInitializer;
import com.iflytek.cloud.SpeechConstant;
import com.iflytek.cloud.SpeechUtility;
import com.systemteam.R;

import java.io.File;

/**
 * Created by gaolei on 16/12/28.
 */

public class DemoApplication extends Application {

    public static String mSDCardPath;
    public static String APP_FOLDER_NAME;

    public void onCreate() {
        super.onCreate();
        //百度地图
        SDKInitializer.initialize(getApplicationContext());
        //科大讯飞初始化
        SpeechUtility.createUtility(this, SpeechConstant.APPID +"=58f9ff61");

        initDirs();
    }

    private boolean initDirs() {
        mSDCardPath = Environment.getExternalStorageDirectory().toString();
        if (mSDCardPath == null) {
            return false;
        }
        APP_FOLDER_NAME = getString(R.string.app_name);
        File f = new File(mSDCardPath, APP_FOLDER_NAME);
        if (!f.exists()) {
            try {
                f.mkdirs();
            } catch (Exception e) {
                e.printStackTrace();
                return false;
            }
        }
        return true;
    }
}
